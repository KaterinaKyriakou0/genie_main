using GenieFramework, Stipple, StipplePlotly
using PlotlyBase

include("projections.jl")
using .Projections


# LOAD DATA

const COAST_FILE = "coastline_points.txt"
const c_lon, c_lat, c_ids = Projections.load_coastline(COAST_FILE)

@genietools


# APP STATE

@app begin
    # Inputs
    @in projection_choice = nothing
    @in lon0 = 0.0
    @in lon_step_choice = 30
    @in plot_choices = ["Coast", "Graticule"]

    # Outputs
    @out plot_data_1 = PlotlyBase.GenericTrace[]
    @out plot_data_2 = PlotlyBase.GenericTrace[]

    @out layout = PlotlyBase.Layout(
        xaxis = PlotlyBase.attr(
            showgrid = false,
            zeroline = false,
            showticklabels = false
        ),
        yaxis = PlotlyBase.attr(
            showgrid = false,
            zeroline = false,
            showticklabels = false,
            scaleanchor = "x"
        ),
        showlegend = false,
        margin = PlotlyBase.attr(l=10, r=10, t=10, b=10),
        paper_bgcolor = "rgba(0,0,0,0)",
        plot_bgcolor = "rgba(0,0,0,0)"
    )
end


# REACTIVE UPDATE (SAFE)

function update_plot()
    if projection_choice !== nothing
        plot_data_1 = build_projection(
            projection_choice,
            lon0,
            lon_step_choice,
            plot_choices,
            c_lon,
            c_lat,
            c_ids
        )

        plot_data_2 = PlotlyBase.GenericTrace[]
    end
end

@onchange projection_choice begin
    update_plot()
end

@onchange lon0 begin
    update_plot()
end

@onchange lon_step_choice begin
    update_plot()
end

@onchange plot_choices begin
    update_plot()
end


# UI

function ui()
    [
        row([
            cell(class="st-module",
                style="height: 65vh; padding: 10px; border-right: 1px solid #e0e0e0;",
            [
                plotly(:plot_data_1, layout=:layout,
                    style="height: 55vh; width: 100%;")
            ]),

            cell(class="st-module",
                style="height: 65vh; padding: 10px;",
            [
                plotly(:plot_data_2, layout=:layout,
                    style="height: 55vh; width: 100%;")
            ])
        ]),

 
        # BOTTOM
        row([
            cell(class="st-module",
                style="padding: 20px; background: #fdfdfd; border-top: 4px solid #1976d2; width: 100%;",
            [

                row(class="items-center", [

                    cell(class="col-2", [
                        h5("Map Settings",
                            style="margin: 0; color: #1976d2; font-weight: 800;"
                        )
                    ]),

                    
                    # PROJECTION SELECT
                    
                    cell(class="col-3 q-px-md", [
                        Stipple.select(:projection_choice,
                            label="Select Projection",
                            options=[
                                Dict("label"=>"Cylindrical: Equidistant", "value"=>1),
                                Dict("label"=>"Cylindrical: Equal-Area (Lambert)", "value"=>2),
                                Dict("label"=>"Cylindrical: Conformal (Mercator)", "value"=>3),
                                Dict("label"=>"Conic: Equidistant", "value"=>4),
                                Dict("label"=>"Conic: Lambert Conformal", "value"=>5),
                                Dict("label"=>"Albers Equal-Area", "value"=>6),
                                Dict("label"=>"Azimuthal: Equidistant", "value"=>7),
                                Dict("label"=>"Stereographic", "value"=>8),
                                Dict("label"=>"Gnomonic", "value"=>9),
                                Dict("label"=>"Orthographic", "value"=>10),
                                Dict("label"=>"Azimuthal: Lambert Equal-Area", "value"=>11),
                                Dict("label"=>"Transverse: Cassini", "value"=>12),
                                Dict("label"=>"Transverse: Mercator", "value"=>13)
                            ],
                            filled=true
                        )
                    ]),

                    
                    # SLIDER 
                    
                    cell(class="col-4 q-px-md", [
                        p("Central Meridian: {{lon0}}°", class="q-mb-none text-weight-bold", style="font-size: 0.85rem; color: #666;"),
                        slider(-180:1:180, :lon0, label=true, class="q-mb-md"),


                        p("Grid Interval",
                            class="q-mb-xs text-weight-bold",
                            style="font-size: 0.85rem; color: #666;"
                        ),

                        Stipple.select(:lon_step_choice,
                            options=[Dict("label"=>"$(i)°", "value"=>i) for i in [5,10,15,20,25,30]],
                            filled=true
                        )
                    ]),

                    
                    # LAYERS
                    
                    cell(class="col-3 q-px-lg", [

                        h6("Map Layers",
                            style="font-size: 0.75rem; text-transform: uppercase; color: #999;"
                        ),

                        Stipple.select(:plot_choices,
                            options=[
                                Dict("label"=>"Show Coastline", "value"=>"Coast"),
                                Dict("label"=>"Show Graticule", "value"=>"Graticule")
                            ],
                            multiple=true,
                            usechips=true,
                            filled=true,
                            emitvalue=true,
                            mapoptions=true
                        )
                    ])
                ])
            ])
        ])
    ]
end

@page("/", ui)

GenieFramework.up()