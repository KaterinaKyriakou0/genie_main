# Conic Projections


using DelimitedFiles
using Plots

# Data 
# coast: [index, lon, lat] and grid: [lon, lat]
coast = readdlm("coastline_points.txt", ',', Float64)  
grid  = readdlm("grid_points.txt", ',', Float64)       

# Convert degrees to radians 
coast_lon = coast[:, 2] .* (π / 180)
coast_lat = coast[:, 3] .* (π / 180)
grid_lon  = grid[:, 1] .* (π / 180)
grid_lat  = grid[:, 2] .* (π / 180)

R = 6371.0  # Earth's radius in km
phi0 = 45 * π / 180  # Standard parallel

# Conic Equidistant Projection
# Radius (r): Distance from the apex of the cone.
# Equations:
#   n = sin(φ₀)
#   r = R * (cot(φ₀) + φ₀ - φ)
#   θ = λ * n
r1_coast = R .* (cot(phi0) .+ phi0 .- coast_lat)
r1_grid  = R .* (cot(phi0) .+ phi0 .- grid_lat)
theta1_coast = coast_lon .* sin(phi0)
theta1_grid  = grid_lon  .* sin(phi0)

x1_coast, y1_coast = r1_coast .* sin.(theta1_coast), r1_coast .* cos.(theta1_coast)
x1_grid, y1_grid   = r1_grid .* sin.(theta1_grid), r1_grid .* cos.(theta1_grid)

# Lambert Conformal Conic
# Equations:
#   n = sin(φ₀)
#   F = [cos(φ₀) * tanⁿ(π/4 + φ₀/2)] / n
#   r = (R * F) / tanⁿ(π/4 + φ/2)
#   θ = n * λ
n = sin(phi0)
F = (cos(phi0) * (tan(π/4 + phi0/2)^n)) / n
r2_coast = (R * F) ./ (tan.(π/4 .+ coast_lat ./ 2).^n)
r2_grid  = (R * F) ./ (tan.(π/4 .+ grid_lat ./ 2).^n)
theta2_coast = n .* coast_lon
theta2_grid  = n .* grid_lon

x2_coast, y2_coast = r2_coast .* sin.(theta2_coast), r2_coast .* cos.(theta2_coast)
x2_grid, y2_grid   = r2_grid .* sin.(theta2_grid), r2_grid .* cos.(theta2_grid)

# Albers Equal-Area 
# Equations:
#   n = sin(φ₀)
#   C = cos²(φ₀) + 2n*sin(φ₀)
#   r = (R / n) * sqrt(C - 2n*sin(φ))
#   θ = n * λ
n3 = sin(phi0)
C = cos(phi0)^2 + 2*n3*sin(phi0)
r3_coast = (R / n3) .* sqrt.(C .- 2 .* n3 .* sin.(coast_lat))
r3_grid  = (R / n3) .* sqrt.(C .- 2 .* n3 .* sin.(grid_lat))
theta3_coast = n3 .* coast_lon
theta3_grid  = n3 .* grid_lon

x3_coast, y3_coast = r3_coast .* sin.(theta3_coast), r3_coast .* cos.(theta3_coast)
x3_grid, y3_grid   = r3_grid .* sin.(theta3_grid), r3_grid .* cos.(theta3_grid)

# Plot
function make_plot(xc, yc, xg, yg, title_str)
    p = scatter(xc, yc, mc=:magenta, ms=2, label="Coast", aspect_ratio=:equal)
    scatter!(p, xg, yg, mc=:blue, m=:cross, ms=3, label="Grid")
    title!(title_str)
    xlabel!("x (km)"); ylabel!("y (km)")
    return p
end

p1 = make_plot(x1_coast, y1_coast, x1_grid, y1_grid, "Conic Equidistant")
p2 = make_plot(x2_coast, y2_coast, x2_grid, y2_grid, "Lambert Conformal")
p3 = make_plot(x3_coast, y3_coast, x3_grid, y3_grid, "Albers Equal-Area")

display(p1)
display(p2)
display(p3)