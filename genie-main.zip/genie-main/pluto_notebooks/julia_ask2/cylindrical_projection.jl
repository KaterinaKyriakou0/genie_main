# Cylindrical projections


using DelimitedFiles
using Plots

# Data 
coast = readdlm("/Users/katherinekyriakou/Desktop/pluto_notebooks/julia_ask2/coastline_points.txt", ',', Float64)  
grid  = readdlm("/Users/katherinekyriakou/Desktop/pluto_notebooks/julia_ask2/grid_points.txt", ',', Float64)       

# Convert degrees to radians (λ = longitude, φ = latitude)
c_lon, c_lat = coast[:, 2] .* (π / 180), coast[:, 3] .* (π / 180)
g_lon, g_lat = grid[:, 1]  .* (π / 180), grid[:, 2]  .* (π / 180)

R = 6371.0  # Mean radius of the Earth in km

# 1. Cylindrical Equidistant 
# Equations: x = R * λ, y = R * φ
x1_c, y1_c = R .* c_lon, R .* c_lat
x1_g, y1_g = R .* g_lon, R .* g_lat

# 2. Cylindrical Equal-Area (Lambert) 
# Equations: x = R * λ, y = R * sin(φ)
x2_c, y2_c = R .* c_lon, R .* sin.(c_lat)
x2_g, y2_g = R .* g_lon, R .* sin.(g_lat)

# 3. Cylindrical Conformal (Mercator)
# Equations: x = R * λ, y = R * ln(tan(π/4 + φ/2))
# We filter out the poles (85°) because the y-coordinate approaches infinity at 90°.
limit = 85 * π / 180
m_c = abs.(c_lat) .< limit
m_g = abs.(g_lat) .< limit

x3_c = R .* c_lon[m_c]
y3_c = R .* log.(tan.(π/4 .+ c_lat[m_c]./2))

x3_g = R .* g_lon[m_g]
y3_g = R .* log.(tan.(π/4 .+ g_lat[m_g]./2))

# Plots 
function plot_map(xc, yc, xg, yg, t)
    p = Plots.scatter(xc, yc, mc=:magenta, ms=1.5, label="Coast", aspect_ratio=:equal)
    Plots.scatter!(p, xg, yg, mc=:blue, m=:cross, ms=2, label="Grid")
    title!(t)
    xlabel!("x (km)"); ylabel!("y (km)")
    return p
end

p1 = plot_map(x1_c, y1_c, x1_g, y1_g, "Cylindrical Equidistant")
p2 = plot_map(x2_c, y2_c, x2_g, y2_g, "Cylindrical Equal-Area")
p3 = plot_map(x3_c, y3_c, x3_g, y3_g, "Cylindrical Conformal (Mercator)")

# Display in a single horizontal row
# plot(p1, p2, p3, layout=(1,3), size=(1200, 400))

display(p1)
display(p2)
display(p3)