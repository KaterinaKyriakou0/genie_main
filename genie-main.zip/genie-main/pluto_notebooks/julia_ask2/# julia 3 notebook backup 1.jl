# julia 2 notebook 
# με ελλειψεις οχι με grid points

using PlutoUI

using DelimitedFiles

using Plots

@bind coast_file FilePicker([MIME("text/plain")])

@bind grid_file FilePicker([MIME("text/plain")])

@bind projection_choice Select([
    1 => "Cylindrical: Equidistant",
    2 => "Cylindrical: Equal-Area (Lambert)",
    3 => "Cylindrical: Conformal (Mercator)",
    4 => "Conic: Equidistant",
    5 => "Conic: Lambert Conformal",
    6 => "Conic: Albers Equal-Area",
    7 => "Azimuthal: Equidistant (Postel)",
    8 => "Azimuthal: Stereographic",
    9 => "Azimuthal: Gnomonic",
    10 => "Azimuthal: Orthographic",
    11 => "Azimuthal: Lambert Equal-Area"
])

begin
	c_lon, c_lat = Float64[], Float64[]
	g_lon, g_lat = Float64[], Float64[]

	if isnothing(coast_file) || isnothing(grid_file)
		"Waiting for files... Please upload both .txt files above."
	else
		coast_data = readdlm(IOBuffer(coast_file["data"]), ',', Float64)
		grid_data  = readdlm(IOBuffer(grid_file["data"]), ',', Float64)

		c_lon = coast_data[:, 2] .* (π / 180)
		c_lat = coast_data[:, 3] .* (π / 180)
		
		g_lon = grid_data[:, 1]  .* (π / 180)
		g_lat = grid_data[:, 2]  .* (π / 180)

		"Data loaded: $(length(c_lat)) coast points, $(length(g_lat)) grid points."
	end
end

begin
	if isempty(c_lon) || isempty(g_lon)
		"Waiting for data to calculate projections..."
	else
		R = 6371.0
		phi0 = 45 * π / 180
		limit_val = 85 * π / 180
		

		# 1. CYLINDRICAL PROJECTIONS
		
		# Equidistant
		x1_c, y1_c = R .* c_lon, R .* c_lat
		x1_g, y1_g = R .* g_lon, R .* g_lat

		# Equal-Area (Lambert)
		x2_c, y2_c = R .* c_lon, R .* sin.(c_lat)
		x2_g, y2_g = R .* g_lon, R .* sin.(g_lat)

		# Conformal (Mercator)
		m_merc_c = abs.(c_lat) .< limit_val
		m_merc_g = abs.(g_lat) .< limit_val
		x3_c, y3_c = R .* c_lon[m_merc_c], R .* log.(tan.(π/4 .+ c_lat[m_merc_c]./2))
		x3_g, y3_g = R .* g_lon[m_merc_g], R .* log.(tan.(π/4 .+ g_lat[m_merc_g]./2))

        # για τα plot : απο πολικες σε καρτεσιανες
		to_cartesian(rho, theta) = rho .* sin.(theta), rho .* cos.(theta)
		
		#  2. CONIC PROJECTIONS 

		# Conic Equidistant
		r_eq_c = R .* (cot(phi0) .+ phi0 .- c_lat)
		r_eq_g = R .* (cot(phi0) .+ phi0 .- g_lat)
		x4_c, y4_c = to_cartesian(r_eq_c, c_lon .* sin(phi0))
		x4_g, y4_g = to_cartesian(r_eq_g, g_lon .* sin(phi0))

		# Lambert Conformal Conic
		n_lcc = sin(phi0)
		F_lcc = (cos(phi0) * (tan(π/4 + phi0/2)^n_lcc)) / n_lcc
		r_lcc_c = (R * F_lcc) ./ (tan.(π/4 .+ c_lat ./ 2).^n_lcc)
		r_lcc_g = (R * F_lcc) ./ (tan.(π/4 .+ g_lat ./ 2).^n_lcc)
		x5_c, y5_c = to_cartesian(r_lcc_c, n_lcc .* c_lon)
		x5_g, y5_g = to_cartesian(r_lcc_g, n_lcc .* g_lon)

		# Albers Equal-Area
		n_alb = sin(phi0)
		C_alb = cos(phi0)^2 + 2 * n_alb * sin(phi0)
		r_alb_c = (R / n_alb) .* sqrt.(max.(0, C_alb .- 2 .* n_alb .* sin.(c_lat)))
		r_alb_g = (R / n_alb) .* sqrt.(max.(0, C_alb .- 2 .* n_alb .* sin.(g_lat)))
		x6_c, y6_c = to_cartesian(r_alb_c, n_alb .* c_lon)
		x6_g, y6_g = to_cartesian(r_alb_g, n_alb .* g_lon)

		

		# 3. AZIMUTHAL PROJECTIONS 

		# Azimuthal Equidistant (Postel)
		rho_postel_c = R .* (π/2 .- c_lat)
		rho_postel_g = R .* (π/2 .- g_lat)
		x7_c, y7_c = to_cartesian(rho_postel_c, c_lon)
		x7_g, y7_g = to_cartesian(rho_postel_g, g_lon)

		# Azimuthal Stereographic (Conformal)
		rho_stereo_c = 2 * R .* tan.(π/4 .- c_lat ./ 2)
		rho_stereo_g = 2 * R .* tan.(π/4 .- g_lat ./ 2)
		x8_c, y8_c = to_cartesian(rho_stereo_c, c_lon)
		x8_g, y8_g = to_cartesian(rho_stereo_g, g_lon)

		# Azimuthal Gnomonic (Clipping near equator)
		m_gn_c = c_lat .> (10 * π / 180)
		m_gn_g = g_lat .> (10 * π / 180)
		rho_gn_c = R .* tan.(π/2 .- c_lat[m_gn_c])
		rho_gn_g = R .* tan.(π/2 .- g_lat[m_gn_g])
		x9_c, y9_c = to_cartesian(rho_gn_c, c_lon[m_gn_c])
		x9_g, y9_g = to_cartesian(rho_gn_g, g_lon[m_gn_g])

		# Azimuthal Orthographic (Northern Hemisphere only)
		m_or_c = c_lat .>= 0
		m_or_g = g_lat .>= 0
		rho_ortho_c = R .* cos.(c_lat[m_or_c])
		rho_ortho_g = R .* cos.(g_lat[m_or_g])
		x10_c, y10_c = to_cartesian(rho_ortho_c, c_lon[m_or_c])
		x10_g, y10_g = to_cartesian(rho_ortho_g, g_lon[m_or_g])

		# Lambert Azimuthal Equal-Area
		rho_laea_c = 2 * R .* sin.((π/2 .- c_lat) ./ 2)
		rho_laea_g = 2 * R .* sin.((π/2 .- g_lat) ./ 2)
		x11_c, y11_c = to_cartesian(rho_laea_c, c_lon)
		x11_g, y11_g = to_cartesian(rho_laea_g, g_lon)

		"Projections calculated: 3 Cylindrical, 3 Conic, and 5 Azimuthal."
	end
end

@bind overlay_choices MultiCheckBox([
    "Coast" => "Show Coastline",
    "Grid"  => "Show Grid Points",
    "Graticule"  => "Show Graticule",
])

md"""
Μεγέθυνση (Zoom): $(@bind zoom_level Slider(1:0.1:20, default=1, show_value=true))
"""

begin
	if isempty(c_lon) || !@isdefined(x1_c)
		"Waiting for data..."
	else
		# 2. Map projection selection
		vars = if projection_choice == 1
			(x1_c, y1_c, x1_g, y1_g, "Cylindrical Equidistant")
		elseif projection_choice == 2
			(x2_c, y2_c, x2_g, y2_g, "Cylindrical Equal-Area")
		elseif projection_choice == 3
			(x3_c, y3_c, x3_g, y3_g, "Mercator")
		elseif projection_choice == 4
			(x4_c, y4_c, x4_g, y4_g, "Conic Equidistant")
		elseif projection_choice == 5
			(x5_c, y5_c, x5_g, y5_g, "Lambert Conformal Conic")
		elseif projection_choice == 6
			(x6_c, y6_c, x6_g, y6_g, "Albers Equal-Area")
		elseif projection_choice == 7
			(x7_c, y7_c, x7_g, y7_g, "Azimuthal Equidistant")
		elseif projection_choice == 8
			(x8_c, y8_c, x8_g, y8_g, "Stereographic")
		elseif projection_choice == 9
			(x9_c, y9_c, x9_g, y9_g, "Gnomonic")
		elseif projection_choice == 10
			(x10_c, y10_c, x10_g, y10_g, "Orthographic")
		else
			(x11_c, y11_c, x11_g, y11_g, "Lambert Azimuthal Equal-Area")
		end

		plt_xc, plt_yc, plt_xg, plt_yg, plt_title = vars

		# υπολογίζει το γεωμετρικό κέντρο, όταν κάνω zoom, εστιάζει στη μέση του χάρτη και όχι στην κάτω αριστερά 
		
		x_mid, y_mid = (maximum(plt_xc) + minimum(plt_xc))/2, (maximum(plt_yc) + minimum(plt_yc))/2
		x_span = (maximum(plt_xc) - minimum(plt_xc)) / (2 * zoom_level)
		y_span = (maximum(plt_yc) - minimum(plt_yc)) / (2 * zoom_level)

		p_final = plot(
			aspect_ratio=:equal, 
			size=(800, 600), 
			title=plt_title,
			xlims=(x_mid - x_span, x_mid + x_span), # Apply zoom
			ylims=(y_mid - y_span, y_mid + y_span)  # Apply zoom
		)
		
		if "Coast" in overlay_choices
			scatter!(p_final, plt_xc, plt_yc, 
				mc=:magenta, ms=0.8, label="Coast", markerstrokewidth=0)
		end
		
		if "Grid" in overlay_choices
			scatter!(p_final, plt_xg, plt_yg, 
				mc=:blue, m=:cross, ms=1.5, label="Grid")
		end
		
		p_final
	end
end