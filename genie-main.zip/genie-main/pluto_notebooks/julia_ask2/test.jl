using Genie, Genie.Renderer.Html
using DelimitedFiles
using Plots
using Base64

# Data
coast = readdlm("coastline_points.txt", ',', Float64)  
grid  = readdlm("grid_points.txt", ',', Float64)       

c_lon, c_lat = coast[:, 2] .* (π / 180), coast[:, 3] .* (π / 180)
g_lon, g_lat = grid[:, 1]  .* (π / 180), grid[:, 2]  .* (π / 180)
R = 6371.0 

# 1. Cylindrical Equidistant 
# Equations: x = R * λ, y = R * φ
x1_c, y1_c = R .* c_lon, R .* c_lat
x1_g, y1_g = R .* g_lon, R .* g_lat

# 2. Cylindrical Equal-Area (Lambert) 
# Equations: x = R * λ, y = R * sin(φ)
x2_c, y2_c = R .* c_lon, R .* sin.(c_lat)
x2_g, y2_g = R .* g_lon, R .* sin.(g_lat)

# 3. Cylindrical Conformal (Mercator)
# Equations: x = R * λ, y = R * ln(tan(π/4 + φ/2))
# We filter out the poles (85°) because the y-coordinate approaches infinity at 90°.
limit = 85 * π / 180
m_c, m_g = abs.(c_lat) .< limit, abs.(g_lat) .< limit
x3_c, y3_c = R .* c_lon[m_c], R .* log.(tan.(π/4 .+ c_lat[m_c]./2))
x3_g, y3_g = R .* g_lon[m_g], R .* log.(tan.(π/4 .+ g_lat[m_g]./2))

# Plot
function plot_to_html(xc, yc, xg, yg, t)
    p = scatter(xc, yc, mc=:magenta, ms=1.5, label="Coast", aspect_ratio=:equal, size=(400,300))
    scatter!(p, xg, yg, mc=:blue, m=:cross, ms=2, label="Grid")
    title!(t)
    
    # Convert Plot to Base64 String
    io = IOBuffer()
    show(io, MIME"image/png"(), p)
    return "data:image/png;base64," * base64encode(take!(io))
end


route("/") do
    # Generate the images
    img1 = plot_to_html(x1_c, y1_c, x1_g, y1_g, "Cylindrical Equidistant")
    img2 = plot_to_html(x2_c, y2_c, x2_g, y2_g, "Cylindrical Equal-Area")
    img3 = plot_to_html(x3_c, y3_c, x3_g, y3_g, "Cylindrical Conformal")

    # Return HTML string
    html("""
    <!DOCTYPE html>
    <html>
    <head><title>Cylindircal Projections</title></head>
    <body style="font-family: sans-serif; text-align: center;">
        <h1>Cylindircal Projections</h1>
        <div style="display: flex; justify-content: space-around; flex-wrap: wrap;">
            <div><h3></h3><img src="$img1" /></div>
            <div><h3></h3><img src="$img2" /></div>
            <div><h3></h3><img src="$img3" /></div>
    </body>
    </html>
    """)
end

# Start server
up(8000)