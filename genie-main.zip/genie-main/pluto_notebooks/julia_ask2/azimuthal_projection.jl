#Azimuthal Projections


using DelimitedFiles
using Plots

# Data 
coast = readdlm("coastline_points.txt", ',', Float64)  
grid  = readdlm("grid_points.txt", ',', Float64)       

# Convert degrees to radians
c_lon, c_lat = coast[:, 2] .* (π / 180), coast[:, 3] .* (π / 180)
g_lon, g_lat = grid[:, 1]  .* (π / 180), grid[:, 2]  .* (π / 180)

R = 6371.0  # Earth's radius

# Convert Polar (ρ, θ) to Cartesian (x, y) for plotting
# x = ρ * sin(θ), y = ρ * cos(θ)
to_cartesian(rho, theta) = rho .* sin.(theta), rho .* cos.(theta)

# Azimuthal Equidistant (Postel)
# Equation: ρ = R * (π/2 - φ)
rho_postel_c = R .* (π/2 .- c_lat)
rho_postel_g = R .* (π/2 .- g_lat)
x1_c, y1_c = to_cartesian(rho_postel_c, c_lon)
x1_g, y1_g = to_cartesian(rho_postel_g, g_lon)

# Azimuthal Stereographic (Conformal)
# Equation: ρ = 2 * R * tan(π/4 - φ/2)
rho2_c = 2 * R .* tan.(π/4 .- c_lat ./ 2)
rho2_g = 2 * R .* tan.(π/4 .- g_lat ./ 2)
x2_c, y2_c = to_cartesian(rho2_c, c_lon)
x2_g, y2_g = to_cartesian(rho2_g, g_lon)


# Azimuthal Gnomonic
# Equation: ρ = R * cot(φ)
# Note: φ must be > 0 (Northern Hemisphere) as the equator projects to infinity.
m_gn_c = c_lat .> (10 * π / 180) # Clipping near equator to avoid ρ -> ∞
m_gn_g = g_lat .> (10 * π / 180)
# Use tan.(π/2 .- lat) as a safer alternative to cot
rho1_c = R .* tan.(π/2 .- c_lat[m_gn_c])
rho1_g = R .* tan.(π/2 .- g_lat[m_gn_g])
x3_c, y3_c = to_cartesian(rho1_c, c_lon[m_gn_c])
x3_g, y3_g = to_cartesian(rho1_g, g_lon[m_gn_g])

# Azimuthal Orthographic 
# Equation: ρ = R * cos(φ)
m_or_c = c_lat .>= 0
m_or_g = g_lat .>= 0
rho3_c = R .* cos.(c_lat[m_or_c])
rho3_g = R .* cos.(g_lat[m_or_g])
x4_c, y4_c = to_cartesian(rho3_c, c_lon[m_or_c])
x4_g, y4_g = to_cartesian(rho3_g, g_lon[m_or_g])

# Lambert Azimuthal Equal-Area Equation
# rho = 2 * R * sin(colatitude / 2)
rho_lambert_c = 2 * R .* sin.((π/2 .- c_lat) ./ 2)
rho_lambert_g = 2 * R .* sin.((π/2 .- g_lat) ./ 2)
# Added missing Cartesian conversion for Lambert
x5_c, y5_c = to_cartesian(rho_lambert_c, c_lon)
x5_g, y5_g = to_cartesian(rho_lambert_g, g_lon)

# Plot
function plot_map(xc, yc, xg, yg, t)
    # Using 'ms' for markersize and 'mc' for markercolor
    # Added 'label=""' to grid to avoid cluttering the legend
    p = scatter(xc, yc, mc=:magenta, ms=0.8, label="Coast", aspect_ratio=:equal, markerstrokewidth=0)
    scatter!(p, xg, yg, mc=:blue, m=:cross, ms=1.5, label="Grid")
    title!(t)
    return p
end

# Plot 
p1 = plot_map(x1_c, y1_c, x1_g, y1_g, "Azimuthal Equidistant (Postel)")
p2 = plot_map(x2_c, y2_c, x2_g, y2_g, "Stereographic")
p3 = plot_map(x3_c, y3_c, x3_g, y3_g, "Gnomonic")
p4 = plot_map(x4_c, y4_c, x4_g, y4_g, "Orthographic")
p5 = plot_map(x5_c, y5_c, x5_g, y5_g, "Lambert Equal-Area")

display(p1)
display(p2)
display(p3)
display(p4)
display(p5)