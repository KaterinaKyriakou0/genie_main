using GenieFramework, Stipple, StipplePlotly, DelimitedFiles, PlotlyBase
@genietools

# --- 1. DATA LOADING ---
const COAST_FILE = "/Users/katherinekyriakou/Desktop/pluto_notebooks/julia_ask2/coastline_points.txt"
const EARTH_RADIUS = 6371.0 

function load_coast(path)
    if isfile(path)
        data = readdlm(path, ',', Float64)
        println("SUCCESS: Loaded $(size(data, 1)) points from file.")
        # Column 1: ID, Column 2: Lon (deg), Column 3: Lat (deg)
        return data[:, 1], data[:, 2] .* (π/180), data[:, 3] .* (π/180)
    else
        println("ERROR: File not found at $path")
        return Float64[], Float64[], Float64[]
    end
end

const C_IDS, C_LON, C_LAT = load_coast(COAST_FILE)

# --- 2. THE APP ---
@app begin
    @in projection_choice = 1 # 1 = Equidistant, 2 = Equal-Area
    @in lon0 = 0.0
    @in plot_choices = ["Coast", "Graticule"]

    @out plot_data_1 = Any[]
    
    @out layout = PlotlyBase.Layout(
        xaxis=attr(showgrid=false, zeroline=false, title="X (km)"),
        yaxis=attr(showgrid=false, zeroline=false, title="Y (km)", scaleanchor="x"),
        margin=attr(l=40, r=40, t=40, b=40),
        height=600
    )

    @onchange projection_choice, lon0, plot_choices begin
        traces = Any[]
        lam0 = lon0 * (π/180)
        
        # --- Graticule ---
        if "Graticule" in plot_choices
            # Latitudes every 30 degrees
            for lat_deg in -60:30:60
                lons = collect(-180:5:180) .* (π/180)
                lats = fill(lat_deg * π/180, length(lons))
                
                adj_l = mod.(lons .- lam0 .+ π, 2π) .- π
                
                xx = EARTH_RADIUS .* adj_l
                yy = (projection_choice == 1) ? (EARTH_RADIUS .* lats) : (EARTH_RADIUS .* sin.(lats))
                
                push!(traces, scatter(x=xx, y=yy, mode="lines", line=attr(color="#bdbdbd", width=0.5)))
            end
        end

        # --- Coastline ---
        if "Coast" in plot_choices && !isempty(C_LON)
            adj_l = mod.(C_LON .- lam0 .+ π, 2π) .- π
            
            # Math
            px = EARTH_RADIUS .* adj_l
            py = (projection_choice == 1) ? (EARTH_RADIUS .* C_LAT) : (EARTH_RADIUS .* sin.(C_LAT))

            # Remove wrap-around lines
            cx, cy = Float64[], Float64[]
            limit = 0.5 * π * EARTH_RADIUS
            for i in 1:(length(px)-1)
                push!(cx, px[i]); push!(cy, py[i])
                if C_IDS[i] != C_IDS[i+1] || abs(px[i]-px[i+1]) > limit
                    push!(cx, NaN); push!(cy, NaN)
                end
            end
            
            push!(traces, scatter(x=cx, y=cy, mode="lines", line=attr(color="magenta", width=1.5)))
        end

        plot_data_1 = traces
    end
end

# --- 3. UI ---
function ui()
    [
        row([
            cell(class="st-module", [
                h4("Cylindrical Projections"),
                plotly(:plot_data_1, layout=:layout)
            ])
        ]),
        row(class="q-pa-md bg-grey-2", [
            cell(class="col-4", [
                # Simple toggle between the two cylindrical types
                radio("Projection Type", :projection_choice, [
                    Dict("label"=>"Equidistant", "value"=>1),
                    Dict("label"=>"Equal-Area", "value"=>2)
                ])
            ]),
            cell(class="col-4", [
                p("Rotate Central Meridian"),
                slider(-180:5:180, :lon0, label=true)
            ]),
            cell(class="col-4", [
                p("Layers"),
                Stipple.select(:plot_choices, options=["Coast", "Graticule"], multiple=true, filled=true)
            ])
        ])
    ]
end

# --- 4. STARTUP ---
@page("/", ui)

# Force the first calculation before the user even connects
# This ensures plot_data_1 isn't empty on load.
# MapApp.trigger!(projection_choice) # If using module, otherwise:
# Note: In some versions, you just need to ensure the variables are initialized.

Server.up()