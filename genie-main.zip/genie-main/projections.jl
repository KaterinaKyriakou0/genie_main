module Projections

using PlotlyBase
using DelimitedFiles


# CONSTANTS
const EARTH_RADIUS = 6371.0



# LOAD COASTLINE

function load_coastline(path::String)
    data = readdlm(path, ',', Float64)

    ids = data[:, 1]
    lon = data[:, 2] .* (π / 180)
    lat = data[:, 3] .* (π / 180)

    return lon, lat, ids
end


# GRATICULE PROJECTION

function get_projected_grid(lons, lats, projection_choice, lon0, phi0, R)

    lam0_rad = lon0 * π / 180
    adj_l = mod.(lons .- lam0_rad .+ π, 2π) .- π

    if projection_choice == 1
        return R .* adj_l, R .* lats

    elseif projection_choice == 2
        return R .* adj_l, R .* sin.(lats)

    elseif projection_choice == 3
        limit = 85 * π/180
        mask = abs.(lats) .< limit
        return R .* adj_l[mask], R .* log.(tan.(π/4 .+ lats[mask]./2))

    elseif projection_choice == 4
        r = R .* (cot(phi0) .+ phi0 .- lats)
        return r .* sin.(adj_l .* sin(phi0)), r .* cos.(adj_l .* sin(phi0))

    elseif projection_choice == 5
        n = sin(phi0)
        F = (cos(phi0) * (tan(π/4 + phi0/2)^n)) / n
        r = (R * F) ./ (tan.(π/4 .+ lats ./ 2).^n)
        return r .* sin.(n .* adj_l), r .* cos.(n .* adj_l)

    elseif projection_choice == 6
        n = sin(phi0)
        C = cos(phi0)^2 + 2 * n * sin(phi0)
        r = (R / n) .* sqrt.(max.(0, C .- 2 .* n .* sin.(lats)))
        return r .* sin.(n .* adj_l), r .* cos.(n .* adj_l)

    elseif projection_choice == 7
        rho = R .* (π/2 .- lats)
        return rho .* sin.(adj_l), rho .* cos.(adj_l)

    elseif projection_choice == 8
        rho = 2 * R .* tan.(π/4 .- lats ./ 2)
        return rho .* sin.(adj_l), rho .* cos.(adj_l)

    elseif projection_choice == 9
        mask = lats .> (15 * π/180)
        r = R .* tan.(π/2 .- lats[mask])
        return r .* sin.(adj_l[mask]), r .* cos.(adj_l[mask])

    elseif projection_choice == 10
        mask = lats .>= 0
        rho = R .* cos.(lats[mask])
        return rho .* sin.(adj_l[mask]), rho .* cos.(adj_l[mask])

    elseif projection_choice == 11
        rho = 2 * R .* sin.((π/2 .- lats) ./ 2)
        return rho .* sin.(adj_l), rho .* cos.(adj_l)

    elseif projection_choice == 12 || projection_choice == 13
        u = atan.(1.0 ./ (cot.(lats) .* cos.(adj_l)))
        v = asin.(cos.(lats) .* sin.(adj_l))
        mask = (abs.(v) .< (π/2 - 0.001)) .& (cos.(adj_l) .> 0)

        if projection_choice == 12
            return R .* v[mask], R .* u[mask]
        else
            return R .* log.(tan.(π/4 .+ v[mask]./2)), R .* u[mask]
        end
    end

    return R .* adj_l, R .* lats
end


# MAIN PROJECTION BUILDER

function build_projection(
    projection_choice,
    lon0,
    step,
    layers,
    c_lon,
    c_lat,
    c_ids
)

    traces = PlotlyBase.GenericTrace[]

    if isempty(c_lon)
        return traces
    end

    R = EARTH_RADIUS
    phi0 = 45 * π / 180
    limit_val = 85 * π / 180

    lam0 = lon0 * π / 180

    # Normalize longitude
    adj_lon = (c_lon .- lam0 .+ π) .% (2π) .- π

    # helper
    to_cartesian(rho, theta) = rho .* sin.(theta), rho .* cos.(theta)

    
    # PROJECTION SELECTION
  

    if projection_choice == 1
        x, y = R .* adj_lon, R .* c_lat

    elseif projection_choice == 2
        x, y = R .* adj_lon, R .* sin.(c_lat)

    elseif projection_choice == 3
        m = abs.(c_lat) .< limit_val
        x, y = R .* adj_lon[m], R .* log.(tan.(π/4 .+ c_lat[m]./2))

    elseif projection_choice == 4
        r = R .* (cot(phi0) .+ phi0 .- c_lat)
        x, y = to_cartesian(r, adj_lon .* sin(phi0))

    elseif projection_choice == 5
        n = sin(phi0)
        F = (cos(phi0) * (tan(π/4 + phi0/2)^n)) / n
        r = (R * F) ./ (tan.(π/4 .+ c_lat ./ 2).^n)
        x, y = to_cartesian(r, n .* adj_lon)

    elseif projection_choice == 6
        n = sin(phi0)
        C = cos(phi0)^2 + 2 * n * sin(phi0)
        r = (R / n) .* sqrt.(max.(0, C .- 2 .* n .* sin.(c_lat)))
        x, y = to_cartesian(r, n .* adj_lon)

    elseif projection_choice == 7
        rho = R .* (π/2 .- c_lat)
        x, y = to_cartesian(rho, adj_lon)

    elseif projection_choice == 8
        rho = 2 * R .* tan.(π/4 .- c_lat ./ 2)
        x, y = to_cartesian(rho, adj_lon)

    elseif projection_choice == 9
        limit = 15 * π / 180
        x = [c > limit ? R * tan(π/2 - c) * sin(l) : NaN for (c,l) in zip(c_lat, adj_lon)]
        y = [c > limit ? R * tan(π/2 - c) * cos(l) : NaN for (c,l) in zip(c_lat, adj_lon)]

    elseif projection_choice == 10
        m = c_lat .>= 0
        rho = R .* cos.(c_lat[m])
        x, y = to_cartesian(rho, adj_lon[m])

    elseif projection_choice == 11
        rho = 2 * R .* sin.((π/2 .- c_lat) ./ 2)
        x, y = to_cartesian(rho, adj_lon)

    elseif projection_choice == 12 || projection_choice == 13
        u = atan.(1.0 ./ (cot.(c_lat) .* cos.(adj_lon)))
        v = asin.(cos.(c_lat) .* sin.(adj_lon))
        m = (abs.(v) .< (π/2 - 0.001)) .& (cos.(adj_lon) .> 0)

        if projection_choice == 12
            x = [m[i] ? R * v[i] : NaN for i in eachindex(v)]
            y = [m[i] ? R * u[i] : NaN for i in eachindex(u)]
        else
            x = [m[i] ? R * log(tan(π/4 + v[i]/2)) : NaN for i in eachindex(v)]
            y = [m[i] ? R * u[i] : NaN for i in eachindex(u)]
        end
    end

    
    # COASTLINE TRACE
    
    if "Coast" in layers
        push!(traces,
            scatter(
                x = x,
                y = y,
                mode = "lines",
                line = attr(width=1),
                name = "Coast"
            )
        )
    end

    
    # GRATICULE
    
    if "Graticule" in layers

        # Parallels
        for lat in -90:step:90
            lons = range(-π, π, length=200)
            lats = fill(lat * π/180, 200)

            gx, gy = get_projected_grid(lons, lats, projection_choice, lon0, phi0, R)

            push!(traces,
                scatter(x=gx, y=gy, mode="lines", line=attr(width=0.5))
            )
        end

        # Meridians
        for lon in -180:step:180
            lons = fill(lon * π/180, 200)
            lats = range(-π/2, π/2, length=200)

            gx, gy = get_projected_grid(lons, lats, projection_choice, lon0, phi0, R)

            push!(traces,
                scatter(x=gx, y=gy, mode="lines", line=attr(width=0.5))
            )
        end
    end

    return traces
end


# EXPORTS

export load_coastline, build_projection

end