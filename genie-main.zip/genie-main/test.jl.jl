using DelimitedFiles

# --- Projection Helper Function ---
function get_projected_grid(lons, lats, projection_choice, lon0, phi0, R)
    lam0_rad = lon0 * π / 180
    adj_l = mod.(lons .- lam0_rad .+ π, 2π) .- π
    
    if projection_choice == 1 # Cylindrical Equidistant
        return R .* adj_l, R .* lats
    elseif projection_choice == 2 # Cylindrical Equal-Area
        return R .* adj_l, R .* sin.(lats)
    elseif projection_choice == 3 # Mercator
        limit = 85 * π/180
        mask = abs.(lats) .< limit
        return R .* adj_l[mask], R .* log.(tan.(π/4 .+ lats[mask]./2))
    elseif projection_choice == 4 # Conic Equidistant
        r = R .* (cot(phi0) .+ phi0 .- lats)
        return r .* sin.(adj_l .* sin(phi0)), r .* cos.(adj_l .* sin(phi0))
    elseif projection_choice == 5 # Lambert Conformal Conic
        n = sin(phi0)
        F = (cos(phi0) * (tan(π/4 + phi0/2)^n)) / n
        r = (R * F) ./ (tan.(π/4 .+ lats ./ 2).^n)
        return r .* sin.(n .* adj_l), r .* cos.(n .* adj_l)
    elseif projection_choice == 6 # Albers Equal-Area
        n = sin(phi0)
        C = cos(phi0)^2 + 2 * n * sin(phi0)
        r = (R / n) .* sqrt.(max.(0, C .- 2 .* n .* sin.(lats)))
        return r .* sin.(n .* adj_l), r .* cos.(n .* adj_l)
    elseif projection_choice == 7 # Azimuthal Equidistant
        rho = R .* (π/2 .- lats)
        return rho .* sin.(adj_l), rho .* cos.(adj_l)
    elseif projection_choice == 8 # Stereographic
        rho = 2 * R .* tan.(π/4 .- lats ./ 2)
        return rho .* sin.(adj_l), rho .* cos.(adj_l)
    elseif projection_choice == 9 # Gnomonic
        mask = lats .> (15 * π/180)
        r = R .* tan.(π/2 .- lats[mask])
        return r .* sin.(adj_l[mask]), r .* cos.(adj_l[mask])
    elseif projection_choice == 10 # Orthographic
        mask = lats .>= 0
        rho = R .* cos.(lats[mask])
        return rho .* sin.(adj_l[mask]), rho .* cos.(adj_l[mask])
    elseif projection_choice == 11 # Lambert Azimuthal Equal-Area
        rho = 2 * R .* sin.((π/2 .- lats) ./ 2)
        return rho .* sin.(adj_l), rho .* cos.(adj_l)
    elseif projection_choice == 12 || projection_choice == 13 # Transverse
        u = atan.(1.0 ./ (cot.(lats) .* cos.(adj_l)))
        v = asin.(cos.(lats) .* sin.(adj_l))
        mask = (abs.(v) .< (π/2 - 0.001)) .& (cos.(adj_l) .> 0)
        if projection_choice == 12 # Cassini
            return R .* v[mask], R .* u[mask]
        else # Transverse Mercator
            return R .* log.(tan.(π/4 .+ v[mask]./2)), R .* u[mask]
        end
    end
    return R .* adj_l, R .* lats 
end

# --- Data Cleaning Helper for Plotly ---
function get_clean_arrays(x, y, R)
    jump_threshold = 0.25 * π * R 
    cx, cy = Float64[], Float64[]
    for i in 1:length(x)
        if i > 1
            if !isfinite(x[i]) || !isfinite(y[i]) || 
               abs(x[i] - x[i-1]) > jump_threshold || 
               abs(y[i] - y[i-1]) > jump_threshold
                push!(cx, NaN); push!(cy, NaN)
            end
        end
        push!(cx, x[i]); push!(cy, y[i])
    end
    return cx, cy
end